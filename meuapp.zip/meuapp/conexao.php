<?php
$host = "tcc_bd1.mysql.dbaas.com.br";
$user = "tcc_bd1";
$pass = "ROSA123456a#";
$db = "tcc_bd1";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("erro_conexao");
}
?>