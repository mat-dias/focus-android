<?php
include "conexao.php";

// recebe dados
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';
$data_nasc = $_POST['data_nasc'] ?? '';
$sexo = $_POST['sexo'] ?? '';

// validação
if($nome == "" || $email == "" || $senha == "" || $data_nasc == "" || $sexo == ""){
    echo "preencha_tudo";
    exit;
}

// criptografa senha
$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

// verifica se email já existe
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows > 0){
    echo "email_existe";
    exit;
}

// insere usuário
$stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, data_nasc, sexo) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $nome, $email, $senhaHash, $data_nasc, $sexo);

if($stmt->execute()){
    echo "cadastro_ok";
} else {
    echo "erro";
}
?>