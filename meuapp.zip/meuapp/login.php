<?php
include "conexao.php";

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

if($email == "" || $senha == ""){
    echo "preencha_tudo";
    exit;
}

$stmt = $conn->prepare("SELECT senha FROM usuarios WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if($row = $result->fetch_assoc()){
    
    if(password_verify($senha, $row['senha'])){
        echo "login_ok";
    } else {
        echo "senha_errada";
    }

} else {
    echo "usuario_nao_existe";
}
?>